import math


class Figura:
    ID = 0

    def __init__(self, kolor):
        if isinstance(kolor, str):
            self._kolor = kolor
        else:
            raise TypeError('Kolor musi być typu string')
        self.nr = Figura.numerowanie()

    @property
    def kolor(self):
        if isinstance(self._kolor, str):
            return self._kolor
        else:
            raise TypeError('Kolor musi być typu string')

    @classmethod
    def numerowanie(cls):
        cls.ID += 1
        return cls.ID

    def przedstaw_sie(self):
        return 'W tej klasie jestem figurą'

    def oblicz_pole(self):
        pass 

    def __str__(self):
        return f'nr {self.numerowanie()} {self.przedstaw_sie()} {self.kolor} {oblicz_pole(self)}'


class Kwadrat(Figura):
    def __init__(self, bok, kolor):
        if isinstance(bok, (int, float)):
            if bok > 0:
                self._bok = bok
            else:
                raise ValueError('Bok kwadratu musi byc liczba dodatnia')
        else:
            raise TypeError('Bok kwadratu musi byc liczba')

        super().__init__(kolor)

    @property
    def bok(self):
        if isinstance(self._bok, (int, float)):
            if self._bok > 0:
                return self._bok
            else:
                raise ValueError('Bok kwadratu musi byc liczba dodatnia')
        else:
            raise TypeError('Bok kwadratu musi byc liczba')

    def oblicz_pole(self):
        return self._bok * self._bok

    def oblicz_obwod(self):
        return 4 * self._bok

    def oblicz_przekatna(self):
        return math.sqrt(2) * self._bok

    def przedstaw_sie(self):
        return 'W tej klasie jestem kwadratem'
    # to nie funkcja obiektu bo jest wprowadzana przez uzytkownika i
    # jest tak naprawde statyczna bo nie operuje na atrybutach obiektu

    def __str__(self):
        return super().__str__(), f'bok {self.bok}'


class Kolo(Figura):
    def __init__(self, promien, kolor):
        if isinstance(promien, (int, float)):
            if promien > 0:
                self._promien = promien
            else:
                raise ValueError('Promień koła musi byc liczba dodatnia')
        else:
            raise TypeError('Promień koła musi byc liczba')

        super().__init__(kolor)

    @property
    def promien(self):
        if isinstance(self._promien, (int, float)):
            if self._promien > 0:
                return self._promien
            else:
                raise ValueError('Promien kola musi byc liczba dodatnia')
        else:
            raise TypeError('Promien kola musi byc liczba')

    @classmethod
    def numerowanie(cls):
        cls.ID += 1
        return cls.ID

    def oblicz_pole(self):
        return math.pi*self._promien*self._promien

    def oblicz_obwod(self):
        return math.pi * 2 * self.promien
    # to nie funkcja obiektu bo jest wprowadzana przez uzytkownika i
    # jest tak naprawde statyczna bo nie operuje na atrybutach obiektu

    def przedstaw_sie(self):
        return 'W tej klasie jestem kołem'

    def __str__(self):
        return super().__str__(), ' promien {self.promien} '


k1 = Kwadrat(1, 'Zielony')
print(k1)
k2 = Kwadrat(10, 'Czarny')
print(k2)
k3 = Kwadrat(10, 'Zielony')
print(k3)
k1._bok = 2
print(k1)
o1 = Kolo(1, 'zolty')
print(o1)
f1 = Figura('Bialy')
print(f1)
