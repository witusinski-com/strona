# class OperacjaMatematyczna:
#     # wartosc nalezy do rzeczywistych
#     # numerowanie w bazowej
#     # funkcja sprawdza czy liczba jest dodatnia: czy_dodatnia
#     # funkcja oblicz abstrakcyjna sluzy do nadpisywania przez funkcje oblicz ktore sa w klasach pochodnych
#     # ma byc dziedziczna
# class Potega(OperacjaMatematyczna):
#     # argument dodatkowy czyli wykladnik w sensie do jakiej potegi podnosimy
#     # wykladnik(wartosc^wykladnik)
#     # funkcja obliczajaca potege
# class Pierwiastek(OperacjaMatematyczna):
#     # pierwiastek kwadratowy
#     # wartosc > 0 jesli nie to value ze nie mozna obliczyc
#     # funkcja obliczajaca pierwiastek
# class Silnia(OperacjaMatematyczna):
#     # wartosc nalezy do naturalnych
#     # funkcja obliczajaca silnie
# kazda klasa musi miec swoj konstruktor i kazda klasa musi miec swoj string
from abc import ABC, abstractmethod
import math


class OperacjaMatematyczna(ABC):
    ID = 0

    def __init__(self, wartosc):
        self.wartosc = wartosc

    def czy_nieujemna(self):
        return self.wartosc >= 0

    @classmethod
    def numerowanie(cls):
        cls.ID += 1
        return cls.ID

    @abstractmethod
    def oblicz(self):
        pass

    def __str__(self):
        return f"Operacja matematyczna na liczbie {self.oblicz()}"


class Potega(OperacjaMatematyczna):
    def __init__(self, wartosc, wykladnik):
        super().__init__(wartosc)
        self.wykladnik = wykladnik

    def oblicz(self):
        return self.wartosc ** self.wykladnik

    def __str__(self):
        return f"Potęga wynosi {self.oblicz()}"


class Pierwiastek(OperacjaMatematyczna):
    def __init__(self, wartosc):
        super().__init__(wartosc)

    def oblicz(self):
        if self.czy_nieujemna():
            return math.sqrt(self.wartosc)
        else:
            raise ValueError("Liczba musi być dodatnia.")

    def __str__(self):
        return f"Pierwiastek wynosi{self.oblicz()}"


class Silnia(OperacjaMatematyczna):
    def __init__(self, wartosc):
        if isinstance(wartosc, int) or wartosc < 0:
            super().__init__(wartosc)
        else:
            raise ValueError("Liczba musi być naturalna.")

    def oblicz(self):
        wynik = 1
        for i in range(1, self.wartosc + 1):
            wynik *= i
        return wynik

    def __str__(self):
        return f"Wynik silni to {self.oblicz()}"


p1 = Potega(3, 4)
print(p1.oblicz())
r1 = Pierwiastek(448900)
print(r1.oblicz())
s1 = Silnia(6)
print(s1.oblicz())
p2 = Potega(6, 7)
print(p2.oblicz())
r2 = Pierwiastek(4489)
print(r2.oblicz())
s2 = Silnia(8)
print(s2.oblicz())
