import math


class MojeNaturalne:
    def __init__(self, wartosc):
        if isinstance(wartosc, int):
            if wartosc >= 0:
                self.__wartosc = wartosc
            else:
                raise ValueError('wartosc musi byc nieujemna')
        else:
            raise TypeError('Wprowadzona wartosc musi byc liczba')

    def __add__(self, other):
        if isinstance(other, MojeNaturalne):
            wartosc = self.__wartosc + other.__wartosc
            return MojeNaturalne(wartosc)
        else:
            raise TypeError('Oba obiekty musza byc typu MojeNaturalne')

    def __mul__(self, other):
        if isinstance(other, MojeNaturalne):
            wartosc = self.__wartosc * other.__wartosc
            return MojeNaturalne(wartosc)
        else:
            raise TypeError('Oba obiekty musza byc typu MojeNaturalne')

    def __floordiv__(self, other):
        if isinstance(other, MojeNaturalne):
            if other.__wartosc != 0:
                wartosc = self.__wartosc // other.__wartosc
                return MojeNaturalne(wartosc)
            else:
                raise ZeroDivisionError('Nie wolno dzielic przez 0')
        else:
            raise TypeError('Oba obiekty musza byc typu MojeNaturalne')

    def __truediv__(self, other):  #potegowanie
        if isinstance(other, MojeNaturalne):
            if self.__wartosc != 0 or other.__wartosc != 0:
                wartosc = int(math.pow(self.__wartosc, other.__wartosc))
                return MojeNaturalne(wartosc)
            else:
                raise ValueError('Taka wartość nie istnieje')
        else:
            raise TypeError('Oba obiekty musza byc typu MojeNaturalne')

    def __sub__(self, other):
        if isinstance(other, MojeNaturalne):
            wartosc = abs(self.__wartosc - other.__wartosc)
            return MojeNaturalne(wartosc)
        else:
            raise TypeError('Oba obiekty musza byc typu MojeNaturalne')

    def __str__(self):
        return f'liczba: {self.__wartosc}'

    def __eq__(self, other):
        if isinstance(MojeNaturalne, other):
            return False
        else:
            return self.__wartosc == other.__wartosc

    def __gt__(self, other):
        if isinstance(MojeNaturalne, other):
            return False
        else:
            return self.__wartosc > other.__wartosc

    def __lt__(self, other):
        if isinstance(MojeNaturalne, other):
            return False
        else:
            return self.__wartosc < other.__wartosc

    def __le__(self, other):
        if isinstance(MojeNaturalne, other):
            return False
        else:
            return self.__wartosc <= other.__wartosc

    def __ge__(self, other):
        if isinstance(MojeNaturalne, other):
            return False
        else:
            return self.__wartosc >= other.__wartosc


l1 = MojeNaturalne(int(input('Podaj liczbe')))
l2 = MojeNaturalne(int(input('Podaj liczbe')))
print("Pierwsza liczba to: {l1}")
print("Pierwsza liczba to: {l1}")
l3 = l1 + l2
print(f"Suma pierwszej i drugiej liczby to {l3}")
print(f"Suma trzeciej i pierwszej liczby to {l3 + l1}")
print(f"Różnica pierwszej i drugiej liczby to {l1 - l2}")
print(f"Różnica pierwszej, drugiej i trzeciej liczby to {l1 - l2 - l3}")
print(l1 * l2)
print(l1 // l2)
print(l1 / l2)
print(l1 == l2)
print(l1 != l2)
print(l1 > l2)
