class Osoba:
    def __init__(self, imie, nazwisko):
        self._imie = imie
        self._nazwisko = nazwisko

    def __str__(self):
        return f'{self._imie} {self._nazwisko}'

    def przedstaw_sie(self):
        return 'Jestem osobą'


class Uczen(Osoba):
    def __init__(self, imie, nazwisko, klasa):
        super().__init__(imie, nazwisko)
        self.klasa = klasa

    def __str__(self):
        return super().__str__()+self.klasa

    # def przedstaw_sie(self):
    #     return 'Jestem uczniem'


class Dzial:
    def __init__(self, nazwa):
        self.nazwa = nazwa

    def __str__(self):
        return self.nazwa


class Pracownik(Osoba, Dzial):
    def __init__(self, imie, nazwisko, nazwadz):
        Osoba.__init__(self, imie, nazwisko)
        Dzial.__init__(self, nazwadz)

    def __str__(self):
        return Osoba.__str__(self)+Dzial.__str__(self)


o1 = Osoba('Jan', 'Kowalski')
print(o1)
print(o1.przedstaw_sie())
u1 = Uczen('Anna', 'Nowak', 3)
print(u1)
print(u1.przedstaw_sie())
p1 = Pracownik('Iga', 'Malak', 'HR')
