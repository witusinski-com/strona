// Definicja funkcji Oblicz (uruchamiana np. po kliknięciu przycisku)
function Oblicz() {

    // Pobranie wartości z inputa (#mid input) i zamiana na liczbę całkowitą
    let liczba = parseInt(document.querySelector("#mid input").value);

    // Pobranie elementu <p> w którym wyświetlimy wynik
    let wynik = document.querySelector("#mid p");

    // Sprawdzenie czy wpisana wartość NIE jest liczbą
    if (isNaN(liczba)) {
        // Jeśli nie jest liczbą – wyświetl komunikat
        wynik.innerHTML = "Podaj liczbę";
        // Zakończ działanie funkcji
        return;
    }

    // Zmienna na zapis binarny (na początku pusta)
    let bin = "";

    // Pętla zamieniająca liczbę dziesiętną na binarną
    while (liczba > 0) {

        // Dodanie reszty z dzielenia przez 2 na początek stringa
        bin = (liczba % 2) + bin;

        // Dzielenie liczby przez 2 i zaokrąglenie w dół
        liczba = Math.floor(liczba / 2);
    }

    // Zmienna na zapis binarny podzielony co 4 bity
    let bin4 = "";

    // Pętla przechodząca po bicie od końca
    for (let i = bin.length - 1, j = 1; i >= 0; i--, j++) {

        // Dodanie kolejnego bitu na początek
        bin4 = bin[i] + bin4;

        // Co 4 bity dodajemy spację (oprócz początku)
        if (j % 4 === 0 && i !== 0) {
            bin4 = " " + bin4;
        }
    }

    // Wyświetlenie wyniku w HTML z dopiskiem systemu binarnego
    wynik.innerHTML = bin4 + "<sub>(2)</sub>";
}
