function obliczKoszt() {
    const szerokosc = parseFloat(document.getElementById('szerokosc').value);
    const dlugosc = parseFloat(document.getElementById('dlugosc').value);
    const panel = document.querySelector('input[name="panel"]:checked').value;
    const wynik = document.getElementById('wynik');

    if (isNaN(szerokosc) || isNaN(dlugosc) || szerokosc <= 0 || dlugosc <= 0) {
        wynik.textContent = "Wprowadź poprawne dane.";
        return;
    }

    const pole = szerokosc * dlugosc;
    const koszt = pole * parseFloat(panel);

    wynik.textContent = `Pole powierzchni pomieszczenia: ${pole.toFixed(2)} m², koszt montażu: ${koszt.toFixed(2)} zł`;
}