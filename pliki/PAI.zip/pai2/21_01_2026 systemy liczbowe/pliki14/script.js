function Oblicz() {
        let liczba = parseInt(document.querySelector("#mid input").value);
        let wynik = document.querySelector("#mid p");

        if (isNaN(liczba)) {
            wynik.innerHTML = "Podaj liczbę";
            return;
        }

        let bin = "";

        while (liczba > 0) {
            bin = (liczba % 2) + bin;
            liczba = Math.floor(liczba / 2);
        }

        let bin4 = "";
        for (let i = bin.length - 1, j = 1; i >= 0; i--, j++) {
            bin4 = bin[i] + bin4;
            if (j % 4 === 0 && i !== 0) bin4 = " " + bin4;
        }

        wynik.innerHTML = bin4 + "<sub>(2)</sub>";
    }