#  suma cyfr danej liczby
import random

def funkcjar(n):
    if n==0:
        return 0
    elif n<10:
        return n
    else:
        return funkcjar(n%10) + funkcjar(n//10)
def funkcjai(n):
    suma=0
    while n>0:
        suma=suma+n%10
        n=n//10
    return suma



# suma cyfr listy
def suma_cyfr_listyR(lista):
    if len(lista) == 1:
        return lista[0]
    return lista[-1]+suma_cyfr_listyR(lista[:-1])




n=int(input("Podaj liczbe naturalna"))
print(funkcjar(n))
print(funkcjai(n))
print(suma_cyfr_listyR(lista))
lista=[]
for i in range(n):
    lista.append(random.randint(0,9))
print(lista)