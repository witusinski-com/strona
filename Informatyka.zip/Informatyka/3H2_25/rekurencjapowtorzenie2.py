a = float(input('Podaj liczbe rzeczywista: '))
n = float(input('Podaj liczbe całkowitą, różną od zera: '))
def potegaR(n, a):
    if n==0:
        return 1
    if n > 0:
        return potegaR(n-1, a)*a

if n < 0:
    print(1/potegaR(n, a))



# print(potegaI(n, a))
print(potegaR(n, a))



